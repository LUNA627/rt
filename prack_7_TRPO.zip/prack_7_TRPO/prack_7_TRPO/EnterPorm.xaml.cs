﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace prack_7_TRPO
{
    /// <summary>
    /// Логика взаимодействия для EnterPorm.xaml
    /// </summary>
    public partial class EnterPorm : Window
    {
        WorkWithData _workWithData = new WorkWithData();
        public EnterPorm()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(Id.Text, out int id) == false)
            {
                MessageBox.Show("Введите корректный id", "Ошибка");
                return;
            }

            string password = Pass.Password;

            if (_workWithData.IsValidData(id, password))
            {
                Doctor currentDoctor = _workWithData.DoctorById(id);
                var infoDoctor = new InfoDoctor(currentDoctor);
                infoDoctor.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("НЕУДАЧА!");
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Hide();
            new MainWindow().Show();
        }
    }
}
