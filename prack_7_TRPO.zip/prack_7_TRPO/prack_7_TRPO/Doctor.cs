﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Printing;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Windows;

namespace prack_7_TRPO
{
    public class Doctor : INotifyPropertyChanged
    {
        private int _id = 0;
        public int Id
        {
            get => _id;
            set
            {
                _id = value;
                OnPropertyChanged();
            }
        }


        private string _name = "Иванов";
        public string Name
        {
            get => _name;
            set
            {
                if (_name != value)
                {
                    _name = value;
                    OnPropertyChanged();
                }
            }
        }

        private string _lastName = "Иван";
        
        public string LastName
        {
            get => _lastName;
            set
            {
                if (_lastName != value)
                {
                    _lastName = value;
                    OnPropertyChanged();
                }
            }
        }

        private string _middleName = "Иванович";
        public string MiddleName
        {
            get => _middleName;
            set
            {
                if (_middleName != value)
                {
                    _middleName = value;
                    OnPropertyChanged();
                }
            }
        }

        private string _specialisation = "Терапевт";
        public string Specialisation
        {
            get => _specialisation;
            set
            {
                if (value != _specialisation)
                {
                    _specialisation = value;
                    OnPropertyChanged();
                }
            }
        }

        private string _password = "Password";

        public string Password
        {
            get => _password;
            set
            {
                if (_password != value)
                {
                    _password = value;
                    OnPropertyChanged();
                }
            }
        }


        public event PropertyChangedEventHandler? PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string? propName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));
        }




         private static Random _rand = new Random();
         private static HashSet<int> _set = new HashSet<int>();

        private static int GenerateUniqId()
        {
            int min = 10000;
            int max = 99999;

            int id;

            do
            {                 
                id = _rand.Next(min, max + 1);

            }
            while (_set.Contains(id));
            _set.Add(id);

            return id;
        }



        public Doctor()
        {
            Id = GenerateUniqId();
        }

       /* [JsonConstructor]
        public Doctor(int id, string name, string lastName, string middleName, string specialisation, string password)
        {
            Id = id;
            Name = name;
            LastName = lastName;
            MiddleName = middleName;
            Specialisation = specialisation;
            Password = password;
        }*/

    }
}
